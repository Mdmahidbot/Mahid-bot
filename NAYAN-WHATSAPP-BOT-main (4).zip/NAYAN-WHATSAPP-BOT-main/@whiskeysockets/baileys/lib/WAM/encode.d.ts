import { BinaryInfo } from './BinaryInfo.js';
export declare const encodeWAM: (binaryInfo: BinaryInfo) => Buffer<ArrayBuffer>;
//# sourceMappingURL=encode.d.ts.map