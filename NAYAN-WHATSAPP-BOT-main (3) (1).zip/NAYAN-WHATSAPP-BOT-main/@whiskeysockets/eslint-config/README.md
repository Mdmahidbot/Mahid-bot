# eslint-config
This project sets a baseline for eslint in all WhiskeySockets projects
